<a name="v2-architecture"></a>

# v2 架構

本文件描述目前 `src-v2/` 的職責與契約，版本以 [release.json](../release.json) 為準。版本別修復及驗證數字移由 [索引](INDEX.md) 與 [TEST_REPORT](TEST_REPORT.md) 保存；本文件不代表新一次驗證通過。

瀏覽器測試只使用 **Codex 內建瀏覽器＋Tampermonkey**，依 [IAB_TESTING](IAB_TESTING.md) 分開來源隔離、實際安裝與環境校準。應用層注入的模型與原生事件不可混為安裝版證據。

<a name="dependency-direction"></a>

## 依賴方向

本節定義目前的依賴方向與檢查邊界；歷史修復與版本證據由 [HISTORY](HISTORY.md) 追溯。

[architecture-rules.mts](../scripts/architecture-rules.mts) 允許的匯入關係如下：

| 匯入層 | 允許的目標層 |
| --- | --- |
| `domain` | `domain` |
| `platform` | `platform` |
| `state` | `state`、`domain`、`platform` |
| `application` | `application`、`state`、`domain`、`platform` |
| `adapters` | `adapters`、`application`、`state`、`domain`、`platform` |
| `diagnostics` | `diagnostics`、`domain` |
| `ui` | `ui`、`diagnostics`、`application`、`state`、`domain`、`platform` |
| `entry.ts` | 所有組合層 |

此表列出可以匯入的層，並不要求全部匯入。狀態儲存元件從 `platform/storage-port.ts` 匯入 `StoragePort` 型別；`platform/storage.ts` 實作 Tampermonkey 儲存。執行識別碼介面也獨立於產生器。各層的 `*-model.ts` 保存共用模型，`*-ports.ts` 保存具名最小依賴介面；單一用途的小模型可與同用途契約共置，單一消費者的介面可留在消費檔。契約不得依賴具體 Store、控制器或適配器。`SettingsChange` 唯一定義於狀態模型；設定視圖僅接收設定、限制清單、原線對照查詢與三個設定命令。UI 匯入應用層／狀態層型別與領域輔助函式，消費快照，透過 `ControlCommandPort` 執行產品變更；UI 不匯入瀏覽器適配器。診斷匯入領域模型。[entry.ts](../src-v2/entry.ts) 建立、連接這些物件並啟動執行環境。

AST 檢查涵蓋 `src-v2/` 下除宣告檔以外的執行期 `.ts`。它檢查值／型別匯入、重新匯出、`import type` 及 `import-equals` 宣告，拒絕非相對匯入與動態 `import()`，並偵測依賴循環與契約對實作的依賴。唯一寫入者依完整相對路徑辨識，不能以同名檔案繞過；只有 `application/measurement-controller.ts` 可以呼叫 `probe.read()`。額外語法規則拒絕領域層／應用層中列出的瀏覽器／GM 全域及直接時鐘／亂數呼叫、路線協調器以外的點號 `setAffinity()` 呼叫、恢復控制器以外應用層的點號 `reload()` 呼叫，以及命令接收器以外列出的 UI 修改操作。這些是語法及依賴檢查，不能完整證明執行期效果或所有權。

獨立的匯入純度測試將全部非入口、非宣告模組打包在一起，停用未使用程式碼移除（tree shaking）並忽略打包最佳化註記，再於不載入 `node:test` 的獨立 Node 子程序匯入，期限為 3 秒。外層具名案例監督結果，框架不受全域陷阱干擾。測試攔截固定清單中的瀏覽器、網路、GM、計時器全域與 `Date.now`／`Math.random`，檢查匯入時行為；建構函式及方法仍須契約測試。架構規則期待各自使用具名 `node:test` 案例；命令、期限與實際保障範圍見 [測試流程](DEVELOPMENT.md#test-suites-and-isolation)。

<a name="domain"></a>

## 領域層

`domain/` 包含純粹的模型與演算法：

- 帶有品牌型別的生命週期及動作 ID；
- URL 接納及主機置換規則；
- 請求 cid 正規化及有界、順序無關的內容父目錄集合比較（`playurl-content.ts`）；
- 內建節點清單（Catalog）定義；
- 有界證據窗口、安全吞吐量及斷路器；
- 候選資格及確定性排名；
- 以可信主機或不透明索引表達的 Catalog 限制快照及播放器輸出計畫；
- 唯讀 playurl 結果模型，明確記錄接納結果、辨識格式、數量、數字上游 `code` 及固定拒絕原因聯集。

領域層以參數接收時間與相對 URL 基底，不執行 I/O。輸出政策函式回傳主機或不透明索引的決策，不提交親和主機（目前路線綁定）或啟動探測。URL 政策輔助函式可以檢查 URL 字串，但不保存它們。

<a name="state"></a>

<a name="cr-0105-與-xhr-所有權補充"></a>

## 狀態層

- `SessionStore` 保存不可變的世代、內容週期、媒體表示及親和主機快照。路線協調器呼叫 `setAffinity`；啟動世代或內容週期時也會在工作階段重設中清除親和主機。
- `RestrictionStore` 依主機與媒體種類管理會到期的黑名單（`black`）／失效（`dead`）紀錄。Catalog 使用者覆寫設定位於 `SettingsStore`，預設值位於領域層 Catalog，當前串流的主機鎖定位於路線協調器／Vault。
- `EvidenceStore` 管理有界的影片／音訊主機證據。
- `SignedRouteVault` 以不透明識別碼管理當前內容週期的完整原生簽名路線（Native）URL。
- 首次可信 playurl API 媒體表示取代同群組較低信任的 page-hint／player-MPD 路線。Vault 撤銷暫時不透明識別碼並變更授權身分；路線協調器在保存身分不符時丟棄計畫及相關權限。後到提示不得為已可信的群組恢復可選 Native 路線。
- 路徑無法辨識的精確簽名 URL 只可建立觀察及主機限制索引，不取得 Native 選路或主動探測能力。
- Vault 也保存有界、當前內容週期的 playurl 輸出 URL 對照，包含原始／輸出主機、主線／備援角色、來源及決策 ID。它擁有選路授權與簽名路線索引，透過不透明識別碼及中繼資料提供候選。完整 URL 仍會經過輸入接納、輸出生成及瀏覽器送出／探測介面。`PlayerAdapter` 在取代／重設前保存序列化資訊清單指紋，XHR 在記憶體保存每筆請求的 URL 狀態；兩者不得成為另一份 Native 授權索引。這些 URL 不持久化，也不包含在診斷請求模型中。
- `SettingsStore` 管理型別化 v2 產品設定，包括正常選路是否參考 B 站 Native 來源的持久開關，預設關閉。
- `SettingsStore.setCatalogEnabled(host, enabled)` 在 settings 鎖內讀取並合併單一節點；一般 update 與 reset 保留完整設定更新／還原語意。
- 可信 MP4／FLV 更新替換同段的有界來源集合；變更時 Vault 撤銷舊 handles、aliases、輸出索引並旋轉授權身分。相同正規化集合不輪替，DASH 保留既有查詢字串處理。
- `MeasurementMetaStore` 管理既有游標／冷卻儲存存取，向呼叫端提供 `measurement` 鎖。

內部原線決策區分原樣通行與 Vault 選中的原線；後者以當前身分與不透明 handle 解析精確 URL，重查政策／禁止規則。同一選定主機上的 DASH 請求保留當次查詢字串。漸進式來源在正規化、去重、容量限制後以集合比較；相同集合更新 primary／順序但保留 handles／aliases／authority，真正新增、移除、換簽名或可信提升仍撤銷。

`EvidenceStore` 只在寫入成功後發布記憶體成功樣本；舊完成或拒絕不能清除新輪次。

| 儲存元件 | 持久鍵 | 讀取／更新行為 |
| --- | --- | --- |
| `SettingsStore` | `bilicdn.v2.settings` | 解析第 2 版資料結構設定，監聽遠端變更，更新／重設時加鎖。原生來源參考預設關閉。 |
| `RestrictionStore` | `bilicdn.v2.restrictions` | 解析有界、會到期的紀錄，監聽遠端變更，修改時加鎖。 |
| `EvidenceStore` | `bilicdn.v2.routeEvidence` | 解析有界影片／音訊證據，監聽遠端變更，記錄／清除時加鎖。 |
| `MeasurementMetaStore` | `bilicdn.v2.meta` | 每次 `get()` 重新讀取儲存；沒有值變更監聽器或快取狀態。 |

[量測中繼資料](../src-v2/state/measurement-meta-store.ts) 保留既有相容語意：接收物件，將游標／時間戳轉為數字並以零作替代，將游標下限設為零。它不強制有限數字上界，也不驗證儲存的資料結構。`update()` 合併既有欄位、寫入資料結構 2 及 `updatedAt`，不自行取得鎖；`clear()` 也直接刪除。`MeasurementController` 以 `withLock()` 包住游標／冷卻更新，並在回呼函式內檢查生命週期標記。

[TampermonkeyStorage](../src-v2/platform/storage.ts) 在可用時以 `bilicdn.v2.` 名稱前綴使用 `navigator.locks`，否則直接執行回呼函式。跨分頁序列化取決於 Web Locks 是否可用。簽名路線與工作階段狀態僅保存在記憶體。

<a name="application-controllers"></a>

## 應用控制器

- `RouteCoordinator` 產生路線決策、套用親和主機、規劃考慮群組的備援，提交證據或路線失效前驗證探測／傳輸結果。
- 僅 `MeasurementController` 啟動主動探測。它管理每分頁一次、由播放器請求觸發的有界起播預測試：最多三個並行候選，共用三秒期限；後續安全輪次依序量測最多三個挑戰候選。MP4／FLV 分段共用起播窗口。路線協調器在提交前驗證起播選擇；健康探索只記錄證據，不變更親和主機。
- 主動起播及健康探測拒絕轉址，只計入已接納主機的直接 206 Range 回應。
- `RecoveryController` 管理播放器核心重載及恢復播放狀態。`RouteCoordinator` 管理路線備援；`PlayerMonitor` 偵測 Watchdog／冷啟動條件，`RuntimeController` 只將 video 備援事件轉交影片核心恢復，audio 不能建立影片恢復意圖。
- `LifecycleController` 在啟動、SPA 導覽鍵變更及啟用／停用變更時開始世代。頁面賦值只作有界待處理輸入，不自動切換世代。
- `PlayerMonitor` 每秒取樣播放器，推進恢復監控週期並提供型別化觀察。
- `PlayurlController` 登記正規化媒體表示、管理內容週期並請求輸出計畫。playurl 適配器負責資料內容解析、欄位相容及寫回。
- `RuntimeController` 協調設定失效、探測／恢復重設、監控器生命週期及備援事件。`ControlCommands` 提供 UI 的型別化修改介面，安排對照、黑名單、重設及資料清除的執行順序。

首個合法起播窗口開始時立即消耗每分頁預算，後來的 Fetch／XHR 先加入共用 pending，再檢查已用預算；epoch／generation／設定 reset 不重開預算，沒有合法候選不消耗。健康量測的 planning／running 以各輪所有權在 finally 清理；probe、儲存鎖或寫入拒絕以固定 measurement-error 收束，遵守 10 分鐘冷卻，不輸出例外內容、不新增立即重試。

控制器接收各用途的具名最小介面；這些介面可從純契約縮小能力，不能從具體類別推導。`NavigationPort`、`SchedulerPort` 及 `PlayerPort.observePlayIntent` 將 History 包裝函式、計時器 API 及啟動意圖檢查留在應用層政策之外。`PlayerPort` 不暴露原始播放器／核心物件。生命週期敏感的探測／傳輸提交依情況檢查當前世代、內容週期、路線身分或控制器標記；證據寫入取得儲存鎖後再次檢查有效性條件。恢復 Promise 使用生命週期序號／權杖，已釋放的生命週期觀察器忽略排隊中的頁面賦值。這些防護適用於生命週期工作；一般使用者設定寫入不綁定世代。

`PlayurlRequestContext` 是內部唯讀 `{ contentId: string | null }`，由 `PlayurlPort.transform` 可選第四參數明確傳入。Fetch 在 await 前從既有平台 Request.url 保存 cid；XHR 在一次參數轉換後建立候選 metadata，failed open 回復舊 metadata，成功重入保留新請求 context。getter 不改讀當前頁面身分。只有現有 `isPlayurlApi` 接納的 URL 可供解析；唯一一個最多 20 位十進位字串，去除前導零，全零／重複／空白／負數／小數／超長均為缺失，避免 Number 精度損失。

`PlayurlController` 私有保存 cid 及已觀察的完整父目錄集合。兩側有效 cid 相同便沿用，不同便換片；任一側缺少時，從各 primary 經 `parseMediaUrl` 取父目錄，忽略主機／查詢／排列。有影片只比影片，兩側純音訊才比音訊，音訊交集不能掩蓋影片變更。交集沿用並合併歷史，支援完整清單與互斥子集往返；非空無交集或型態改變則重設。首次 cid 對齊既有目錄後綁定，無法對齊先重設。無 cid 且沒有有效目錄不變更基準。影片 128／音訊 64 上限，優先本次集合、舊集合按固定字串排序填入，不因淘汰本身增加 epoch。

只有 trusted-api 更新內容基準，保留重複回應／同物件防篡改及 generation 防護；低信任提示不觸發換片或擴充歷史，generation 改變清空全部基準。cid／目錄不持久化、不進診斷，也不提供 Native 授權。沒有有效 cid 或共同路徑的同片無法可靠辨識，仍保守重設；此修復不新增 API 逆序回應政策。來源與回歸詳見 [BR-03 修復報告](BR03_FIX_REPORT.md)。

真正內容改變時，`PlayurlController` 在 Session／Vault／Routes 重設後、登記新表示前，同步通知 generation／epoch。Runtime 訂閱後重設監控、量測、恢復及播放器快取，釋放時取消訂閱。同片排列及 cid 可對齊的畫質／編碼切換不通知，每分頁一次的起播預算不重開。

`RouteCoordinator` 擁有單調路線政策修訂號；設定／對照模式失效及內容重設會遞增。`TransportContext` 在建立請求時保存修訂號。傳輸證據寫入維持原生命週期／授權檢查，完成後若政策過期便停止控制副作用；儲存鎖等待後再次檢查，合法固定主機優先於健康親和。

`platform/runtime-ids.ts` 的 factory 由入口呼叫，以 Web Crypto 產生執行環境前綴並注入傳輸及選路控制器。request／startup／challenge ID 在工作建立時分配，同工作重報不換 ID；字串沿用 schema 2 原欄位，上限 64 字元，不帶 URL 或使用者資料。模組匯入不取得亂數。

量測鎖回呼先重查最新安全狀態、表示與控制器標記，才選擇記錄嘗試的候選及提交冷卻；首次播放位置只作基準。普通恢復在 seek／ended／mediaError 時先終止舊動作，再考慮還原；只有仍擁有停滯／操作修訂的 BR-01 stall 意圖可處理持續 seeking。play Promise 檢查生命週期與當前 token，避免晚到拒絕覆寫較新結果。

`PlayerControlSnapshot` 只提供媒體／核心不透明數字識別、seek／使用者操作修訂、拖曳、目標位置及自有 reload 修訂。`PlayerAdapter` 觀察播放器區域可信 pointer／非 seek key，後者僅 keydown；BR-07 的 seek 鍵可來自 BODY／頁面。keydown／keyup 捕捉皆只保存一筆私有候選，排除 editable／控制中心／組字／Ctrl／Meta／Alt／合成輸入；候選的事件仍派送、同播放器／媒體／生命週期、真正可見且有限位置改變，並 seeking 或 readyState 0／捕捉核心未變／非 internalReload，才更新一次 userRevision。site.seek、媒體觀察、controls 與該事件種類的 window 冒泡皆可確認；同派送去重，keydown、repeat、keyup 各自造成新 seek 時各自取得修訂。新事件撤銷上一候選，外層冒泡／timeout 必須檢查候選身分。eventPhase NONE 拒絕派送後工作，可取消零延遲 timeout 只清理參照，不提供延遲窗口或鍵盤按住狀態。入口注入 Scheduler 與真正可見性查詢，DOM／事件不交給應用層。一般 site seek 更新觀察修訂，腳本 seek 使用內部標記並清除候選；pendingSeek 保守抑制來源，不因可信輸入全面清空。reset 移除監聽器，僅在仍擁有方法時還原 wrapper。Monitor 仍以新使用者修訂重開停滯，網站／Auto 的單純 seekRevision 保留原期限。BODY 播放／倍速另採私有 keydown 候選：Space、k／K 或既有倍速鍵須在該派送內確實改變 paused／有限 rate，且核心也仍相同，才能增加一次 userRevision；腳本的還原方法不消費此候選。頁面核心標記是因果觀察，並非認證：等待自有 reload 時未經可觀察方法的外部替換仍有辨識限制。

BR-08 進度命中使用 target.closest 的 `.bpx-player-progress-wrap, .bpx-player-progress, .bilibili-player-video-progress, [role="slider"]`，命中祖先仍須位於目前播放器區域；不向下搜尋子節點。可信進度 pointerdown 立即建立單一私有手勢，不要求 seeking 或位置改變。手勢保存 pointerId、媒體、播放器與內容生命週期，controls.dragging 由有效所有者推導。新合法進度按下取代舊手勢，非進度按下保留有效手勢；只有同指標可信 pointerup／pointercancel／lostpointercapture 釋放。同步重入須核對觀察版本及手勢物件，不能覆寫或清除較新手勢；hidden、失焦、reset、媒體／播放器替換及內容失效撤銷手勢，不新增 timeout 或 pointer capture。

`VisibilityAdapter.subscribeControlLoss(listener): () => void` 是適配器內部通知。既有可信 blur／真正 hidden guard 在 stopImmediatePropagation 前通知 `PlayerAdapter`，單一 listener 的例外不破壞原 guard。入口明確注入，取消函式由播放器控制觀察管理，reset／重新綁定清理；controls() 仍以真正可見性查詢防漏。BR-08 不變更公開 API、`PlayerControlSnapshot`、應用層介面與 schema 2，不傳遞 DOM／事件或播放器物件到應用層。

`PlayerMonitor` 擁有單一停滯段、起點、政策升級與動作額度；Recovery 擁有 token、重載與還原。Runtime 只轉交合資格 video 備援；同段通知不能重開計時或額度。一般／長 seek 的資格與時點統一見 [產品契約](PROJECT_CONTEXT.md#recovery-contract)。

BR-01 後續恢復透過內部可選 `PlayerPort.ownedReload(revision): boolean` 查詢自有 reload 所有權，不把 DOM 或核心物件交給應用層。`PlayerAdapter` 私有紀錄本次 reload 修訂、原媒體／播放器／核心、生命週期、使用者修訂與第一個替換核心，最多有界保存 15 秒；每次查詢重查身分及真正可見性。暫時空核心可等待，但舊核心在空隙後回來、第二次替換、新操作、hidden／control-loss 或 reset 撤銷所有權。還原 wrapper 與 timer 清理各自核對物件／方法所有權，不能清掉較新工作。

`RecoveryController.ongoingStallReload` 提供 Monitor 唯讀資格查詢；只有同停滯 token 與合法自有 reload 才可跨過 SDK 暫時 paused／空核心，Monitor 不在此期間重建停滯或取消同一救援。首個非零替換核心須標記等於本次修訂、初始化狀態不是 false，並通過健康觀察，才可還原；不能把空核心上的舊標記當成資格。沒有有效目標證明時，SDK 自行 seek 只更新目前目標與觀察身分，禁止舊位置還原；有效的倍速／播放意圖仍受本次 token、最新路線授權與期限限制。新的可信操作、可觀察的外部 reload 或第二次核心替換撤銷該例外；首個替換的因果觀察不能認證所有未經可觀察方法的外部替換，普通 pause 政策保持。

重載後無進度達 15 秒先完成一次失敗終止並釋放 token，不能因 adapter 自有觀察到期只留下模糊 ownership-ended。真正時間／影格進度仍須操作、媒體／核心與 seek 修訂一致；首次有效進度停止無進度重載計時，兩次連續有效採樣才 recovered，SDK 位置跳躍及保留尺寸不算進度。已還原且有首次進度時，`ongoingStallReload` 另以相同穩定所有者維持最多 15 秒的確認資格，不延長 adapter 的 pause／空核心租期，也不授予新的 seek／rate／play 或核心接納；未形成持續進度仍失敗。終止後保存失敗停滯的 userRevision／mediaId，SDK 自行 resume 不重開救援；真正進度或新的使用者／媒體所有權才可清除此抑制。跨租期確認、同步重入、晚到完成及清理由正式契約覆蓋；具體版本的執行結果及安裝證據見 TEST_REPORT。

停滯、舊 watchdog、冷起播三個監控救援入口皆排除 dragging，拖曳期間清除舊停滯及 watchdog 連續計數，不消耗一次性起播救援嘗試。釋放後第一個合資格 tick 從最新位置建立新基準：仍在 seeking 或有未完成可信目標使用 15／30 秒，其餘 6／12 秒。冷起播仍按原 firstMediaAt 重評，可能立即救援，不新增全域釋放寬限或重開起播預算。

`RouteCoordinator.recoveryEligible` 為唯讀查詢：核對請求 generation／epoch／政策／授權修訂、Vault video 身分、身分綁定計畫、固定主機及現行限制。`RecoveryController` 建立 token 前讀取控制基準，位置／倍速各讀取一次，收集後重新取 controls 與最新資格，再核對生命週期、媒體／核心／seek／使用者修訂、現有 token、breaker 及總額；拖曳不得建立恢復意圖。reload 及 seek／rate／play 每個副作用前仍重查捕獲資格與所有權；重載替換只接納標記相符的自有替換。已初始化核心的普通等待亦有 30 秒上限，既有死核心／冷起播 4 秒及長暫停觸發維持。

<a name="v2124-可信播放按鈕意圖"></a>

### 長暫停後的可信播放意圖

長暫停後，網站核心可能忽略播放按鈕而不呼叫 SDK play。`PlayerAdapter` 同時觀察現有 SDK 方法及目前播放器區域的可信 `.bpx-player-ctrl-play` click；僅同一 paused 媒體、播放器、內容週期、真正可見且非 ended/error 才通知既有意圖。讀取前後核對控制／使用者修訂與清理狀態，事件與 DOM 不傳入應用層。

可信播放的資格與期限見 [產品契約](PROJECT_CONTEXT.md#recovery-contract)。每輪返回的取消函式清理自有 document 捕捉監聽器，SDK 方法只還原自有包裝；Runtime reset 先解除 Recovery 訂閱。

可信未完成目標由單一 PlayerControlObserver 保存，與原生觀察 targetSec 分離；RecoveryPlayerPort 的必要捕獲／驗證方法只交付有限位置與不透明證明，token 保留捕獲結果而不建立第二份目標權威。來源包括同派送鍵盤及目前 pointer 手勢；真正 0、新目標取代、播放交接、目標完成、未知變動與失效由 Observer 管理。Adapter 注入時鐘供進度合理性判斷，領域層仍只比較傳入事實。

有效目標證明只允許本次 reload 修訂下第一個受認可替換核心的首個有界 SDK 初始化 seek；首個穩定播放基準關閉該窗口。等待 seeking 結束後才還原目標、倍速及播放。第二 seek／核心、外部 reload、新操作、未知原生位置或原 15 秒到期都不得延長授權。沒有證明的舊路徑保持原取消規則。此例外的自動證據與實際安裝結果分列於救援修復紀錄。

<a name="progressive-playurl-processing-v218"></a>

<a name="漸進式-playurl-處理v218"></a>

## 漸進式 playurl 處理

[PlayurlAdapter](../src-v2/adapters/playurl.ts) 在有界深度內走訪已辨識的根層／`data`／`result`／`video_info` 容器，收集 DASH 與 MP4／FLV `durl`。分段身分包含分支、格式、畫質及陣列索引；缺少或重複的 `order` 不會合併不同分段。資料內容保留原始分段順序與中繼資料，DASH 編解碼器排序獨立運作。解析器拒絕格式錯誤的資料內容、非零頂層 `code`、不支援格式及超過容量的影片／音訊項目。

控制器逐段登記，維持當前世代／內容週期及可信來源提升規則。漸進式 Catalog 生成從 `SignedRouteVault` 取得該段第一個安全來源的不透明識別碼，不假設第一個提供的 URL 可以改寫。精確來源路徑／查詢字串保持與本段關聯。Vault 僅在換主機後能生成正常內建 Catalog 目標時，才可為此保留安全可改寫的 PCDN 來源；它不取得 Native 可選資格，也不得成為第二份 URL 索引。DASH 保留既有行為：同媒體表示中，傳入的安全精確 URL 或 Catalog 別名 URL 連同當前查詢字串保留。

所有已辨識的漸進式或混合格式輸出，先完成規劃才寫回 URL。必要分段若沒有合法主線，拒絕整個回應，不部分取代 URL 或丟棄失敗分段。此原子性限於資料內容寫回，不回滾 Vault／控制器登記。既有僅含 DASH 清空欄位處理另行維持。[PlayurlTransformResult](../src-v2/domain/playurl-model.ts) 表達結果；每個消費端都檢查 `accepted`，不能只判斷結果物件是否為真值。

僅使用 Catalog 模式下，Fetch 拒絕的 playurl 變成安全 HTTP 503 回應。XHR `text`（文字）／`json`（JSON）讀取存取器提供安全失敗內容，保留原生 HTTP 狀態；嚴格模式不支援的 XHR 回應類型在送出前拒絕。允許 Native、原線對照及整體停用原樣放行的政策維持各自語意。Fetch／XHR 等待後仍重查設定與生命週期有效性。

<a name="adapters"></a>

## 適配器

XHR waiting 請求的內部原生 open 準備最多兩次，包含政策目標變更的 reopen。每次 open、responseType、timeout、credentials 及每個 header 還原後，均以安裝時保存的原生 readyState getter 加上 metadata 身分／phase 判斷能否繼續；準備後重新計算最新合法目標，完全穩定才建立歸因及 send。gate continuation 的未交付原生例外只終止仍擁有當前請求的 waiter，依序送出一次 readystatechange／error／loadend，保留 DONE 與空回應。直接 send 的原生例外仍同步拋出；未接受的 native send 清除 pending 歸因而不記錄 CDN 失敗樣本，已送出請求不重播。

起播等待的三個取消邊界使用 signal.reason 原值，包括物件身分與 falsy 值；只有缺少 reason 能力才建立 AbortError。拒絕只屬於該等待者，共用 probe controller 與每分頁預算維持原語意，各完成路徑以 finally 移除 listener。

適配器將瀏覽器行為轉為型別化觀察：

- 獨立的 `FetchHookAdapter` 與 `XhrHookAdapter`，透過 `TransportContext` 共用型別化送出檢查及觀察建構；
- `TransportAdapter` 安裝／驗證兩個攔截，還原不完整安裝並回報整合攔截快照；
- `RangeProbeAdapter` 提供起播及健康探測共用的直接同主機 HTTPS 206 讀取器，限制計入 bytes、傳遞取消並釋放讀取器。量測控制器管理期限及結果解讀；路線協調器管理授權檢查與證據提交。失敗的健康挑戰不開啟播放斷路器；
- playurl 解析及轉換寫回；
- `__playinfo__` 與播放器資訊清單接納；
- 影片／播放器解析；
- `BrowserNavigation`：僅在包裝函式仍擁有 History 方法時還原，取消訂閱後忽略排隊中的回呼函式；
- `BrowserScheduler`：為延遲／週期計時器回傳取消函式，並排入不可取消的微任務；
- 可見性／背景行為；
- 可還原的 WebRTC 封鎖。

Tampermonkey 儲存及值變更監聽器由 `platform/storage.ts` 實作。適配器不擁有選路政策或施加懲罰。應用層的計時器分別由量測期限、播放器監控的週期計時器及生命週期微任務管理；恢復由監控器監控週期推進。UI 直接面向瀏覽器：`PlayerPanel` 擁有獨立的 1.5 秒週期計時器，`ControlCenter` 直接排入焦點工作。

XHR 每次 open 建立獨立 metadata，區分 opened／waiting／sent／terminal。參數依序轉換一次後，先暫存新所有權供同步事件使用，原生 open 成功才永久清理舊請求；拋錯只在候選仍為當前所有者時回復，不能覆蓋巢狀成功 open。尚未原生送出的取消與本地拒絕由該 metadata 擁有；每個事件回呼後重查所有權，舊 headers／progress 監聽也先檢查身分。reopen／abort 不讓舊 loadend 或 gate 繼續影響新請求。虛擬終止使用 DONE、空回應及終止事件；waiting 的自有中止完成後回到 UNSENT，尚未原生送出的其他 abort 依原生狀態處理，不一律改成 UNSENT。原生已送出的事件由瀏覽器處理。readyState／response／responseText 與方法攔截共同追蹤安裝所有權，只還原仍由本攔截持有的描述子。同步重開只保留合法選項，非同步重開保留 timeout、responseType、credentials 與 headers。

XHR header 依 ByteString 在入口轉換一次，原生接受後才存字串供內部 reopen；body 的字串分支在 phase 變更前轉為 USVString，原例外保留，更正後可送出。平台品牌檢查保留跨 realm Blob／Document／FormData／URLSearchParams／ArrayBuffer／view，轉換重入後重新取得 metadata；已送出請求不重播。原生未送出的 abort 不一律變成 UNSENT，正式替身依原生對照校準。

Chrome 同步選項驗證失敗可能把原生 XHR 清成 UNSENT；只有尚未送出的 waiting 請求可標記 needsNativeOpen，在 gate 釋放時重新準備，再檢查所有權與最新政策；已送出的請求絕不因此重播。版本別例外對照由 [HISTORY](HISTORY.md) 追溯。

XHR 的 response／responseText 共用同一組文字轉換及快取助手，JSON 分支也由該助手處理；助手只取得當次 metadata 與最小轉換能力。原生 getter、readyState／responseType／世代檢查與模式切換快取重置仍在 hook，status 延遲至原有診斷通知位置讀取。重入只保留當次 metadata，沒有新增 in-flight 去重或第二索引。

`ControlCenter` 在開啟、關閉及換頁時更新視圖版本；命令完成與排隊焦點只在仍擁有當前開啟視圖時作用。設定命令完成不代表 UI 必須仍開啟。

`ControlCenter` 私有管理 ShadowRoot 的 keydown／keypress／keyup 冒泡監聽器；只隔離目前開啟、已連接宿主及當前 ShadowRoot 的可信事件。一般按鍵只停止傳播，保留原生預設行為；Escape keydown 另取消預設並關閉。show 不重複註冊，close／宿主重建移除舊監聽器。外層捕捉處理仍先執行，不宣稱全面隔離任何網站鍵盤邏輯。

### 控制中心複製所有權

診斷複製在可信 click 內立即呼叫原生 Clipboard API，保留 receiver 與當次完整文字；API 不可取得時才呼叫一次 GM 純文字備援。原生拋錯／拒絕不自動改走 GM。單一 `ControlCenter` 的 pending 寫入跨關閉／重開仍有效，提示與按鈕只更新原宿主／ShadowRoot／視圖；不重新產生報告、不搶焦點、不新增剪貼簿讀取。GM 返回只提示交由管理器處理，不宣告複製成功。

原生 Promise 完成不取代完整讀回驗收；例外只顯示固定失敗提示，不輸出內容或錯誤細節。v2.1.22 的本輪證據見 [P05 修復報告](P05_COPY_FIX_REPORT.md)。

<a name="native-position-ownership"></a>

## 原生位置與保存值

`PlayerAdapter` 的私有 NativePosition 只保存一筆媒體、播放器、生命週期、有限位置及 readyState 基準。HAVE_NOTHING 的未知目標變更更新既有 targetSec／seekRevision，撤銷過期位置還原；未取得可信派送證據時不增加 userRevision。getter 返回後重查觀察版本、原基準、操作修訂、pendingSeek 及當前所有者；reset／替換清除基準，自有 reload 初始零另有來源標記。

`RecoveryPlayerPort.captureResumePosition()` 優先捕獲 Observer 仍有效且未完成的可信目標與不透明證明；沒有該目標才捕獲原有位置讀取結果。Recovery 的 stall 路徑在沒有證明時沿用該段 `targetSec`，其他路徑沿用捕獲位置及有限值回退。內部 `PlayerControlSnapshot` 新增可選 `pendingSeekGoal` 供 Monitor 選擇長 seek 政策；不是持久欄位或第二個目標所有者。

`currentTime()` 在目前 video.readyState===0 時一次讀取原生位置，有限值（包含 0）優先於 SDK 快取；其他情況保留 SDK／snapshot 回退。例外回退只涵蓋該次原生 readyState／currentTime 讀取，不保證 video 選取或所有 snapshot getter 例外安全。Recovery 在保存前後及副作用前繼續核對 mediaId、coreId、seekRevision、userRevision、lifecycleSerial、路線與資格；保存值不授予新權限。

<a name="visibility-boundary"></a>

## 網站前景偽裝與內部可見性

[VisibilityAdapter](../src-v2/adapters/visibility.ts) 安裝時保存 Document.prototype 的 hidden getter，再於 document 實例覆寫 hidden=false、visibilityState=visible。網站因此看到前景；`isActuallyVisible()` 透過保存的 getter 查詢內部資格。Runtime／監控／量測使用此資格，不從被覆寫的頁面值推斷前景。

真正 hidden 與可信且 `event.target === window` 的 blur guard 在阻擋事件前通知控制失效，供 `PlayerAdapter` 清理手勢及所有權。子元素 blur 經 window 捕捉不取得視窗失焦資格；既有事件遮蔽保留。背景播放本身可持續；背景停止的是不合資格的主動量測／救援與舊還原提交。

保存 getter 缺失時會退回 visibilityState；讀取拋錯時按現有 fail-open 行為視為未隱藏，dispose 後查詢也回傳可見。因此可見性查詢本身不是原生 getter 來源或背景能力的保證，測試仍須先校準。

測試需要校準保存的 getter 來源與真正分頁切換。prototype 讀值與 Runtime 若共用 getter，並非兩份獨立原生證明；面板隱藏或工具選取 ID 也不是原生 hidden 的證據。步驟與無效窗口判定見 [IAB_TESTING 的 E04](IAB_TESTING.md#visibility)。可見性清理的描述子所有權限制見 [SECURITY](../SECURITY.md#browser-behavior)。

<a name="route-lifecycle"></a>

## 路線生命週期

1. 可信 playurl 回應或有界頁面／播放器提示建立媒體表示群組。
2. Vault 保存當前世代／內容週期的精確 Native URL。
3. 路線協調器接納當前候選、套用限制並排名。原生來源開關關閉時，正常選路只接納生成的內建 Catalog 路線；原始及 Native 簽名 URL 留在 Vault，供歸因及獨立對照模式使用。
4. 第一筆符合條件的 Fetch／非同步 XHR 媒體請求可等待最多三秒的合法路線並行預測試，同窗口的全部請求共用期限。開關關閉時只探測 Catalog；可辨識的 B 站媒體 URL 若不能安全生成合法 Catalog 路線，送出前封鎖。
5. 傳輸適配器在送出時請求決策，保存不可變的請求脈絡。
   Fetch 政策輸入與原生送出使用同一個平台正規化 Request；頁面自行加入的 `href` 屬性不能讓受檢 URL 與送出 URL 不同。
   監控器／UI 啟動前先嘗試安裝攔截並記錄驗證狀態；安裝失敗不阻止 UI 啟動。傳輸層檢查可辨識的非 GET 媒體但不改寫，XHR 在 `send()` 重查。開關關閉時，不能送往允許 Catalog 路線的已辨識媒體請求，在原生呼叫前封鎖，包括非 GET 及舊世代請求。
6. 完成後產生型別化觀察並更新證據。已確認失敗可開啟媒體種類斷路器，請求考慮群組的備援。
7. 冷啟動無進度時可提交一次不同主機的合法備援，並啟動既有的一次性核心恢復。原生來源開關關閉時，備援也必須是 Catalog。
8. 以決策後觀察到的主機確認路線結果，不能只憑計畫。

Catalog HTTP 403 只失效當前串流／主機配對，影響後續排名、備援及主動挑戰。恢復依媒體種類記錄從計畫、攔截入口到回應或失敗的有界動作；來自無關決策的同主機請求不能確認該動作。

開啟持久原生來源參考後，正常選路可依原有規則考慮合法原始及精確 Native 簽名路線。關閉時，playurl 只輸出安全生成的 Catalog 主備 URL；沒有合法路線時，輸出沒有可用路線。它不取消已送出的網站請求。整體停用仍原樣保留網站請求。

原線對照僅存在目前分頁的路線協調器，獨立於持久原生來源開關。它只使用影片提供的合法精確簽名 URL；主線被禁止時可提升合法原始備援，並停用主動探測及自動恢復。切換時清除計畫／親和主機，重設量測／核心恢復。完整重載後不保留，也不回溯還原已交給播放器的 URL。

健康量測不得變更親和主機。

Catalog 保留全部 11 個內建主機，其中 4 個預設不可用。起播三個探測的限制不縮小一般排名、備援或後續健康探索的候選池。僅使用 Catalog 輸出選擇合法主線及最多五個與主線及彼此不同主機的合法備援。當前黑名單（`black`）／失效（`dead`）、使用者覆寫設定、預設可用性、主機鎖定及串流／主機不相容限制仍有效。

僅使用 Catalog 起播沒有有效探測結果時，不提交測速贏家。最終送出對完整剩餘合法 Catalog 池作一般排名；探測 403 仍排除當前串流／主機配對。保留期限限制，不讓失敗探測路線取得特別優先權。

模式依序套用整體停用、分頁原線對照；正常選路再套用固定／自動選路及原生來源開關。固定主機、Catalog 覆寫設定或原生來源設定變更會失效計畫並重設量測／恢復。等待中的起播結果不得覆蓋新固定主機；最終送出使用當前設定與授權。

<a name="diagnostics"></a>

## 診斷

記錄器消費型別化 `DomainEvent`，彙總成功流量並保存有界失敗事故。UI 讀取模型為快照，讀取不能改變選路或啟動網路工作。攔截入口、媒體辨識、原生呼叫及回應階段與瀏覽器網路面板（Network）確認分開。僅使用 Catalog 規則涵蓋腳本改寫的 playurl 輸出及可攔截媒體送出；其他瀏覽器入口的流量須另行觀察。

`RouteSnapshot`、`TransportSnapshot`、`DiagnosticSnapshot` 及 `ControlCenterSnapshot` 提供具體唯讀欄位。診斷請求序列化使用明確的有界欄位清單，匯出時清理傳入的讀取模型。外部資料內容由對應適配器／儲存元件解析器驗證，中繼資料則保留上述相容行為。產品設定／選路命令使用 `ControlCommandPort`；UI 也直接呼叫僅作診斷的標記、清除及報告操作。UI 不直接讀寫儲存鍵。

`TransportSnapshot.lastPlayurl` 保存一筆不可變的最近結果：Fetch／XHR、觀察時間、原生 HTTP 狀態、接納結果、辨識出的 DASH／MP4／FLV 格式、影片／音訊／分段數量、數字上游 `code` 及拒絕原因。`TransportContext` 複製固定欄位清單，去重後最多三種格式，數量限制為 0–65,535，丟棄非有限值或非安全整數的上游 `code`。不複製原始資料內容、URL、路徑、權杖或例外文字。控制中心及既有診斷匯出消費此摘要；接納結果不證明實際網路目的地或播放成功。

診斷同一次嘗試只有首次有效回應初始化播放進度基準；後續同身分及同路線成功不撤回 playback-observed／首次 playbackAt，也不延長 30 秒觀察期限。混合主機、seek、生命週期及新嘗試仍按原契約中斷。

具名回歸、來源隔離、已封存安全差異與剩餘限制見 [v2.1.23 修復報告](CR01_CR05_FIX_REPORT.md)。

## 模組責任邊界

| 協調／所有者 | 獨立助手 | 保留權責 |
| --- | --- | --- |
| RouteCoordinator | routing/ 的請求分類、資格、傳輸結果、證據組裝、候選、限制、URL 物化及播放器主備規劃 | 所有政策修訂、計畫、工作 ID、事件、等待後重新驗證、傳輸提交、親和與 Vault 登記 |
| DiagnosticRecorder | 單一 event-sanitizer、route-attempt-tracker、report | 事件／流量／事故緩衝；報告助手只消費去敏後的 detached capture |
| ControlCenter | labels／styles／elements／overview／settings／diagnostics views | 宿主／封閉 ShadowRoot、鍵盤／焦點、視圖版本與 pending 複製 |
| PlayerAdapter | media／sdk／method 與單一 PlayerControlObserver | 既有外部及測試覆寫介面；所有控制修訂、監聽器及自有重載觀察集中於 observer |
| PlayerMonitor／RecoveryController | domain/playback-progress 的純控制身分、時間及影格比較 | Monitor 保有停滯段；Recovery 保有 token、額度、breaker、reload／restore；兩者各自保留資格、基準、計數與終止檢查順序 |
| XhrHookAdapter | xhr-values／xhr-request／xhr-response | 唯一 metadata WeakMap、原生 getter／guards、派送、安裝與按所有權還原；回應助手只轉換及快取當筆狀態 |

助手沒有第二份 Native 授權索引或可獨立變更親和的能力。嘗試追蹤保留六個 attempt、32 個 request IDs 與既有期限；responseIds 集合沒有另加明確數量上限，不能把所有內部集合描述成逐項有界。詳見 [模組化紀錄](MODULARIZATION_v2.1.25_REPORT.md)。
